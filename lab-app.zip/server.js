const express = require('express');
const { Pool } = require('pg');
const os = require('os');

const app = express();

const port = process.env.PORT || 3000; 

// Configuração do Pool de conexão usando Variáveis de Ambiente
const pool = new Pool({
  user: process.env.DB_USER,
  host: process.env.DB_HOST,
  database: process.env.DB_NAME,
  password: process.env.DB_PASSWORD,
  port: process.env.DB_PORT || 5432,
});

app.get('/', async (req, res) => {
  try {
    // Garante que a tabela existe (facilita o lab, pois não exige script SQL manual)
    await pool.query(`
      CREATE TABLE IF NOT EXISTS visitas (
        id SERIAL PRIMARY KEY, 
        data_visita TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);
    
    // Registra a nova visita
    await pool.query('INSERT INTO visitas DEFAULT VALUES');
    
    // Conta o total de visitas
    const result = await pool.query('SELECT COUNT(*) AS total FROM visitas');
    
    // Pega o hostname do nó atual (ex: node-12345)
    const hostname = os.hostname();

    res.send(`
      <div style="font-family: Arial, sans-serif; text-align: center; margin-top: 50px;">
        <h1 style="color: #2c3e50;">Lab Alta Disponibilidade - NodeJS</h1>
        <p style="font-size: 18px; color: #27ae60;"><strong>Aplicação conectada com sucesso.</strong></p>
        <div style="background-color: #f8f9fa; padding: 20px; border-radius: 8px; display: inline-block; margin-top: 20px; border: 1px solid #dee2e6;">
          <p>🖥️ <strong>Nó que respondeu esta requisição:</strong> <span style="color: #e74c3c;">${hostname}</span></p>
          <p>💾 <strong>Total de visitas registradas no Banco:</strong> <span style="color: #2980b9;">${result.rows[0].total}</span></p>
        </div>
        <p style="margin-top: 20px; font-size: 14px; color: #7f8c8d;">Atualize a página (F5) para ver o balanceador de carga NGINX alternando os nós.</p>
      </div>
    `);
  } catch (err) {
    console.error('Erro no banco de dados:', err);
    res.status(500).send('<h2 style="color: red;">Erro ao conectar no banco de dados. Verifique as variáveis de ambiente.</h2>');
  }
});

app.listen(port, () => {
  console.log(`Servidor rodando na porta ${port}`);
});
